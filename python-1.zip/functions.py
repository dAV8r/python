def greet_user(name):
    print('Hi there ' + name + '!')
    print('Welcome aboard!')


#Always add two line breaks after a function definition
print("Start")
greet_user("Rabbit")
print("Finish")
