numbers = [1,1,1,1,1,1,2,2,2,2,2,2,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9]
print("The original list is: " + str(numbers))
uniques = []

for number in numbers:
    if number not in uniques:
        uniques.append(number)
print(uniques)
    #print(number)
    #if numbers.count(number) > 1:
        #numbers.remove(number)
        #print(numbers)

#print("The list without duplicates is: " + str(numbers))
