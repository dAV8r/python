def largest_num(numbers):
    largest = numbers[0]
    for number in numbers:
        if number > largest:
            largest = number
    print("The largest number in the list is: " + str(largest))
    return largest
