import random


class Dice:
    def roll(self):
        diceNum = (random.randint(1,6),random.randint(1,6))
        print(diceNum)
        return diceNum


dice1 = Dice()
dice1.roll()

