import printModules
from printModules import print_lyrics


theName = printModules.print_name_func()
print_lyrics(theName)