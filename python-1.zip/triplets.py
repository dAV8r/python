

print(abs(a[0]-a[2]))