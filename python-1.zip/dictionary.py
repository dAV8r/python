customer = {
    "name":"John Doe",
    "age": 30,
    "is_verified": True
}

print(customer["name"])
print(customer.get("name"))
print(customer.get("birthdate","Jan 1, 1990"))