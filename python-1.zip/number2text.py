numbers = {
    "1": "One",
    "2": "Two",
    "3": "Three",
    "4": "Four",
    "5": "Five",
    "6": "Six",
    "7": "Seven",
    "8": "Eight",
    "9": "Nine",
    "0": "Zero"
}

text = []
number = input("Phone: ")

output = ""
for digit in number:
    print(numbers.get(digit,"!"))
    text.append(numbers.get(digit, "!"))
    output += numbers.get(digit,"!") + " "
print(text)
print(output)

