weight = float(input("Enter Weight: "))

convert_from = input("Entered weight is (L)bs or (K)g: ")

print(convert_from)

if convert_from.upper() == "L":
    converted_weight = weight * 0.453592
    print("The weight in Kg is " + str(converted_weight) + " kilos.")
elif convert_from.upper() == "K":
    converted_weight = weight / 0.453592
    print("The weight in Lbs is " + str(converted_weight) + " pounds.")
else:
    print("Please enter the weight in valid format.")