good_creditScore = True
high_income = True
price = 1000000

if high_income and good_creditScore:
    print("You have to pay 10% of the total cost as down-payment")
    down_payment = 0.1 * price
    print("Amount to be paid is $" + str(down_payment))
else:
    print("You have to pay 20% of the total cost as down-payment")
    down_payment = 0.2 * price
    print("Amount to be paid is $" + str(down_payment))
