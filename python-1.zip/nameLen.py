name = input("Enter the name")

name_length = len(name)

if name_length < 3:
    print("The name should be more than 3 characters long")
elif name_length > 50:
    print("The name should be less than 50 characters long")
else:
    print("name looks good")
