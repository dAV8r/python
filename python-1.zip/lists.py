numbers = [2,5,7,1,8,3,9,100,23,47,76]
largest = numbers[0]
for number in numbers:
    if number > largest:
        largest = number
print("The largest number in : " + str(numbers) +" is " + str(largest))