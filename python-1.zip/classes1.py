class Person:
    def __init__(self,name):
        self.name = name


    def talk(self):
        print("Hello!" + " I am " + self.name)


person1 = Person("Seamus")
print(person1.name + " says ")
person1.talk()