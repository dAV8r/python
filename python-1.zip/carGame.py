
print('Enter "help" for commands list ')

isGameOn = True
gameInput = ""
isCarStarted = False
while isGameOn:
    gameInput = input("> ").lower()

    if gameInput == "start":
        if isCarStarted:
            print("Car is already started")
        else:
            print("Car started...Ready to go!")
            isCarStarted = True
    elif gameInput == "stop":
        if not isCarStarted:
            print("Car is already stopped")
        else:
            print("Car stopped.")
            isCarStarted = False
    elif gameInput == "help":
        print("""Enter "start" to start the car
Enter "stop" to stop the car
Enter "quit" to quit the game""")
    elif gameInput == 'quit':
        break
    else:
        print("I did not understand that.")



