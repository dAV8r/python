prices = [10, 20, 30]
totalCost = 0

for price in prices:
    totalCost += price

print("TotalCost: "+ str(totalCost))