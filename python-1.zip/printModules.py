def print_name_func():
    name = input("What is your name?")
    print(name)
    return name


def print_lyrics(name):
    print("welcome to the hotel california " + name + "!")