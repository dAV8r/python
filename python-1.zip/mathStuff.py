import math

print(math.ceil(2.9))

print(math.floor(2.9))

is_hot = True

if is_hot:
    print("its a hot day");
    print("Drink lots of water")
print("Enjoy your day")