print('Ashwin Vinu')
print('=o----/')
print('  ||||')
print('*' * 10)

price = 10

print(price)


name = input("What is your name?")
fav_color = input("What is your favourite color")

print(name + " likes " + fav_color + ".")

x = 2.9

print(round(x))