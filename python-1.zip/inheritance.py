class Mammal:
    def walk(self):
        print("walking")



class Dog(Mammal):
    def bark(self):
        print("Bow-wow")


class Cat(Mammal):
    def meow(self):
        print("meowwwww")



cat1 = Cat()
cat1.meow()
cat1.walk()

dog1 = Dog()
dog1.bark()
dog1.walk()