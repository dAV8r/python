from largestModule import largest_num

numbersList = [76,85,58,94,49,10,120]

largest = largest_num(numbersList)

print(largest*5)