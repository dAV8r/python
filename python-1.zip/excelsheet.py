import openpyxl as xl
from openpyxl.chart import BarChart, Reference

wb = xl.load_workbook("transactions.xlsx")
sheet = wb["Sheet1"]
cell = sheet["a1"]
cell = sheet.cell(1, 1)
print(cell.value)
print(sheet.max_row)

cell = sheet.cell(1, 5)
cell.value = "post_discount"

for row in range(2, sheet.max_row + 1):
    #print(row)
    cell = sheet.cell(row, 3)
    print(cell.value)
    discountedPrice = cell.value*0.9
    discountedPrice_cell = sheet.cell(row, 5)
    discountedPrice_cell.value = discountedPrice

values = Reference(sheet,
                   min_row=2,
                   max_row=sheet.max_row,
                   min_col=4,
                   max_col=4)

chart = BarChart()
chart.add_data(values)
# cell = sheet.cell(2,6)
sheet.add_chart(chart, "f2")

wb.save("transactions2.xlsx")

