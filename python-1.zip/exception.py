try:
    age = int(input("Age: "))
    print("The age is : " + str(age))
    income = 20000
    risk = income/age
except ValueError:
    print("Please enter numeric digits only!")
except ZeroDivisionError:
    print("Age cannot be zero!")



