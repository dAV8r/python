number = input("Phone: ")


def number_to_text(phoneNum):
    numbers = {
        "1": "One",
        "2": "Two",
        "3": "Three",
        "4": "Four",
        "5": "Five",
        "6": "Six",
        "7": "Seven",
        "8": "Eight",
        "9": "Nine",
        "0": "Zero"
    }

    output = ""
    for digit in phoneNum:
        #print(numbers.get(digit, "!"))
        output += numbers.get(digit, "!") + " "
    return output



display = number_to_text(number)

print(display)

