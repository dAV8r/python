# lists, but immutable. i.e, cannot perform operations like append, remove etc.
#cannot mutate or change tuples

numbers = (1,2,3)

print(numbers.index(1))

coordinates = (1,2,3)

x = coordinates[0]
y = coordinates[1]
z = coordinates[2]

print(x*y*z)

#unpacking : same as above, but in one line. works with lists as well.


x,y,z = coordinates

print(x*y*z)