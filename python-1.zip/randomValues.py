import random

members = ["John","Hamish","Watson"]

for i in range(2):
    print(random.choice(members))


x = random.randint(1,6)
y = random.randint(1,6)

print("(" + str(x) + "," + str(y) + ")")