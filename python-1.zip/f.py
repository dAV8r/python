numbers = [5,2,5,2,2]

for number in numbers:
    output = ""

    for xx_count in range(number):
        output += "x"
    print(output)
